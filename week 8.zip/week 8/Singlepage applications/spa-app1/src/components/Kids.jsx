const Kids = ()=>{
    return(
        <>
          <h1>Kids....</h1>
        </>
    )
}
export default Kids;