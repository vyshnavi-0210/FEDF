const Laptops = ()=>{
    return(
        <>
          <h1>Laptops soon...</h1>
        </>
    )
}
export default Laptops;