const Fashion = ()=>{
    return(
        <>
          <h1>Fashion...</h1>
        </>
    )
}
export default Fashion;