const Mobiles = ()=>{
    return(
        <>
          <h1>Mobiles soon...</h1>
        </>
    )
}
export default Mobiles;